CREATE VIEW available_bikes AS
  SELECT
    `b`.`type_id`       AS `type_id`,
    `b`.`active`        AS `active`,
    `b`.`bike_id`       AS `bike_id`,
    `b`.`purchase_date` AS `purchase_date`,
    `b`.`price`         AS `price`,
    `b`.`make`          AS `make`,
    `b`.`station_id`    AS `station_id`,
    `b`.`type_name`     AS `type_name`,
    `b`.`rental_price`  AS `rental_price`
  FROM ((`hermanrm`.`active_bikes` `b`
    JOIN `hermanrm`.`bike_type` `bt`
      ON (((`b`.`type_id` = `bt`.`type_id`) AND (`b`.`active` = `bt`.`active`) AND (`b`.`type_name` = `bt`.`type_name`)
           AND (`b`.`rental_price` = `bt`.`rental_price`)))) LEFT JOIN `hermanrm`.`unfinished_repairs` `ur`
      ON ((`ur`.`bike_id` = `b`.`bike_id`)))
  WHERE (isnull(`ur`.`bike_id`) AND (`b`.`station_id` IS NOT NULL));

