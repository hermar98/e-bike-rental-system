CREATE VIEW active_bikes AS
  SELECT
    `hermanrm`.`bike`.`type_id`           AS `type_id`,
    `hermanrm`.`bike`.`active`            AS `active`,
    `hermanrm`.`bike`.`bike_id`           AS `bike_id`,
    `hermanrm`.`bike`.`purchase_date`     AS `purchase_date`,
    `hermanrm`.`bike`.`price`             AS `price`,
    `hermanrm`.`bike`.`make`              AS `make`,
    `hermanrm`.`bike`.`station_id`        AS `station_id`,
    `hermanrm`.`bike_type`.`type_name`    AS `type_name`,
    `hermanrm`.`bike_type`.`rental_price` AS `rental_price`
  FROM (`hermanrm`.`bike`
    JOIN `hermanrm`.`bike_type` ON (((`hermanrm`.`bike`.`type_id` = `hermanrm`.`bike_type`.`type_id`) AND
                                     (`hermanrm`.`bike`.`active` = `hermanrm`.`bike_type`.`active`))))
  WHERE (`hermanrm`.`bike`.`active` = TRUE);

