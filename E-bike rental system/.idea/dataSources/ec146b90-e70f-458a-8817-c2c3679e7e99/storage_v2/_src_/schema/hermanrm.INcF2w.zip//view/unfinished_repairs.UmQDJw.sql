CREATE VIEW unfinished_repairs AS
  (SELECT
     `r`.`repair_id`    AS `repair_id`,
     `r`.`date_sent`    AS `date_sent`,
     `r`.`request_desc` AS `request_desc`,
     `r`.`bike_id`      AS `bike_id`,
     `r`.`active`       AS `active`
   FROM ((`hermanrm`.`repair` `r`
     JOIN `hermanrm`.`active_bikes` `b` ON ((`r`.`bike_id` = `b`.`bike_id`))) LEFT JOIN `hermanrm`.`done_repair` `dr`
       ON ((`r`.`repair_id` = `dr`.`repair_id`)))
   WHERE isnull(`dr`.`repair_id`));

