CREATE VIEW recent_bike_data AS
  SELECT
    `bd`.`bike_id`      AS `bike_id`,
    `bd`.`date_time`    AS `date_time`,
    `bd`.`coords_lat`   AS `coords_lat`,
    `bd`.`coords_lng`   AS `coords_lng`,
    `bd`.`charging_lvl` AS `charging_lvl`,
    `bd`.`trip_id`      AS `trip_id`
  FROM ((`hermanrm`.`bike_data` `bd`
    JOIN (SELECT
            `hermanrm`.`bike_data`.`bike_id`        AS `bike_id`,
            max(`hermanrm`.`bike_data`.`date_time`) AS `max_date`
          FROM `hermanrm`.`bike_data`
          GROUP BY `hermanrm`.`bike_data`.`bike_id`) `gbd`
      ON (((`bd`.`bike_id` = `gbd`.`bike_id`) AND (`bd`.`date_time` = `gbd`.`max_date`)))) JOIN `hermanrm`.`bike`
      ON ((`bd`.`bike_id` = `hermanrm`.`bike`.`bike_id`)))
  WHERE (`hermanrm`.`bike`.`active` = TRUE);

