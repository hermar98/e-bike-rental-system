CREATE VIEW travelling_bikes AS
  SELECT
    `rbd`.`bike_id`      AS `bike_id`,
    `rbd`.`date_time`    AS `date_time`,
    `rbd`.`coords_lat`   AS `coords_lat`,
    `rbd`.`coords_lng`   AS `coords_lng`,
    `rbd`.`charging_lvl` AS `charging_lvl`,
    `rbd`.`trip_id`      AS `trip_id`
  FROM ((`hermanrm`.`recent_bike_data` `rbd`
    JOIN `hermanrm`.`active_bikes` `ab` ON ((`ab`.`bike_id` = `rbd`.`bike_id`))) LEFT JOIN
    `hermanrm`.`unfinished_repairs` `ur` ON ((`ur`.`bike_id` = `rbd`.`bike_id`)))
  WHERE (isnull(`ab`.`station_id`) AND isnull(`ur`.`bike_id`));

