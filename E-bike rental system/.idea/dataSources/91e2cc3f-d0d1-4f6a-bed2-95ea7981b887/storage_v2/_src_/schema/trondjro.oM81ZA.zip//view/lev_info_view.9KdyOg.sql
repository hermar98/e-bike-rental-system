CREATE VIEW lev_info_view AS
  SELECT
    `lbf`.`levnr`   AS `levnr`,
    `li2`.`navn`    AS `navn`,
    `li2`.`adresse` AS `adresse`,
    `lbf`.`fylke`   AS `fylke`,
    `li2`.`postnr`  AS `postnr`
  FROM (`trondjro`.`levinfo2` `li2`
    JOIN `trondjro`.`lev_by_fylke` `lbf` ON ((`lbf`.`levnr` = `li2`.`levnr`)));

