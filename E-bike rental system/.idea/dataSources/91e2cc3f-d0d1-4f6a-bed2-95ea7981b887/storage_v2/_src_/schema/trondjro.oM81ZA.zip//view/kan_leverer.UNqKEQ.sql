CREATE VIEW kan_leverer AS
  SELECT
    `levere_hele_el_deler`.`levnr`      AS `levnr`,
    sum(`levere_hele_el_deler`.`total`) AS `sum`
  FROM `trondjro`.`levere_hele_el_deler`
  GROUP BY `levere_hele_el_deler`.`levnr`
  HAVING (count(0) = (SELECT count(0)
                      FROM `trondjro`.`ordredetalj`
                      WHERE (`trondjro`.`ordredetalj`.`ordrenr` = 18)));

