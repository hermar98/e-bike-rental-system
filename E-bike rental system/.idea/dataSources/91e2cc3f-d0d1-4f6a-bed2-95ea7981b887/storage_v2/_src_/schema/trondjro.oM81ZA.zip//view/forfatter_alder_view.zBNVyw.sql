CREATE VIEW forfatter_alder_view AS
  SELECT
    concat(`trondjro`.`forfatter`.`fornavn`, ' ', `trondjro`.`forfatter`.`etternavn`) AS `navn`,
    concat((`trondjro`.`forfatter`.`dod_aar` - `trondjro`.`forfatter`.`fode_aar`))    AS `alder`
  FROM `trondjro`.`forfatter`
  WHERE (`trondjro`.`forfatter`.`dod_aar` IS NOT NULL)
  UNION SELECT
          concat(`trondjro`.`forfatter`.`fornavn`, ' ', `trondjro`.`forfatter`.`etternavn`) AS `navn`,
          concat((year(curdate()) - `trondjro`.`forfatter`.`fode_aar`))                     AS `alder`
        FROM `trondjro`.`forfatter`
        WHERE ((`trondjro`.`forfatter`.`fode_aar` >= 1900) AND isnull(`trondjro`.`forfatter`.`dod_aar`));

