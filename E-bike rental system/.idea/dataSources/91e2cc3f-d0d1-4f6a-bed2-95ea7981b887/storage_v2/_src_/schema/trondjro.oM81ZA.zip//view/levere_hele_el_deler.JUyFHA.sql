CREATE VIEW levere_hele_el_deler AS
  SELECT
    concat((`pi`.`pris` * `od`.`kvantum`)) AS `total`,
    `pi`.`levnr`                           AS `levnr`,
    `pi`.`delnr`                           AS `delnr`
  FROM (`trondjro`.`prisinfo` `pi`
    JOIN `trondjro`.`ordredetalj` `od` ON ((`pi`.`delnr` = `od`.`delnr`)))
  WHERE (`od`.`ordrenr` = 18);

