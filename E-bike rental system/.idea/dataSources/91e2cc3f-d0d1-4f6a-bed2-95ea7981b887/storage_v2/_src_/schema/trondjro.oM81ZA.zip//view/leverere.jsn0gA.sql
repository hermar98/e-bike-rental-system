CREATE VIEW leverere AS
  SELECT
    `trondjro`.`prisinfo`.`levnr`                                               AS `levnr`,
    `trondjro`.`prisinfo`.`delnr`                                               AS `delnr`,
    concat((`trondjro`.`prisinfo`.`pris` * `trondjro`.`ordredetalj`.`kvantum`)) AS `totalpris`
  FROM (`trondjro`.`prisinfo`
    JOIN `trondjro`.`ordredetalj` ON ((`trondjro`.`prisinfo`.`delnr` = `trondjro`.`ordredetalj`.`delnr`)))
  WHERE (`trondjro`.`ordredetalj`.`ordrenr` = 18);

