CREATE VIEW kan_levere AS
  SELECT
    `leverere`.`levnr`          AS `levnr`,
    sum(`leverere`.`totalpris`) AS `totalpris`
  FROM `trondjro`.`leverere`
  GROUP BY `leverere`.`levnr`
  HAVING (count(0) = (SELECT count(0)
                      FROM `trondjro`.`ordredetalj`
                      WHERE (`trondjro`.`ordredetalj`.`ordrenr` = 18)));

